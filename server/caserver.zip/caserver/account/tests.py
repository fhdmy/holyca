from django.test import TestCase

# Create your tests here.
# account="1256623447@qq.com",
# password="HolyHolyCA",
# auth="b858c001e8961049919f500f84ff87f39a3ff7de;842e1835db42cc0044151199a5fc24be83ac4c6c;1584627749"
# account="holyca@126.com",
# password="HolyHolyCA",
# auth="ba729318a506a1ec476654053cf7e7483b1056df;eff1d56f879b05be0b8f53cf3aec7d65bffdc2fe;1584699974"
